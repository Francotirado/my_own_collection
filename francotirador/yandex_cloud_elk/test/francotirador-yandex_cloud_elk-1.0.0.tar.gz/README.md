# Ansible Collection - francotirador.yandex_cloud_elk

Custom collection with `my_module` for file creation.

## Role: my_module
Creates a file using the custom module.

### Default variables:
- `path`: ./hello.txt
- `content`: "Hello World from my own module!"
